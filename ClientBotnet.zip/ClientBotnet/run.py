# By @Dently (Telegram)

from pyrogram import Client, filters, idle
from asyncio import sleep as sleep
from os import system as terminal
from datetime import datetime as time

app = {
1: Client("bot1"),
2: Client("bot2"),
3: Client("bot3"),
4: Client("bot4"),
5: Client("bot5"),
6: Client("bot6"),
7: Client("bot7"),
8: Client("bot8"),
9: Client("bot9"),
10: Client("bot10"),
11: Client("bot11"),
12: Client("bot12"),
13: Client("bot13"),
14: Client("bot14"),
15: Client("bot15"),
16: Client("bot16"), 
17: Client("bot17"),
18: Client("bot18"),
19: Client("bot19"),
20: Client("bot20"),
21: Client("bot21"),
22: Client("bot22"),
23: Client("bot23"),
24: Client("bot24"),
25: Client("bot25"),
26: Client("bot26"),
27: Client("bot27"),
28: Client("bot28"),
29: Client("bot29"),
30: Client("bot30"),
31: Client("bot31"),
32: Client("bot32"),
33: Client("bot33"),
34: Client("bot34"),
35: Client("bot35"),
36: Client("bot36"),
37: Client("bot37"),
38: Client("bot38"),
39: Client("bot39"),
40: Client("bot40"),
41: Client("bot41"),
42: Client("bot42"),
43: Client("bot43"),
44: Client("bot44"),
45: Client("bot45"),
46: Client("bot46"),
47: Client("bot47"),
48: Client("bot48"),
49: Client("bot49"),
50: Client("bot50"),
51: Client("bot51"),
}

accounts = 0; deads = 0
for _ in app:
	try:
		app[_].start()
		me = app[_].get_me()
		if len(me.first_name) >= 12:
			name = me.first_name[:12] + '...'
		else:
			name = me.first_name
		print(f'{time.now()} | INFO     | botnet.cli:main:56 | {name}({me.id}) launched')
		accounts += 1
	except:
		deads += 1
	
for _ in app:
	bn = app[_]
	@bn.on_message(filters.command('join', '*') & ~filters.private & ~filters.channel)
	async def join(client, message):
		if message.from_user.id != 1556864374:
			return
		if len(message.command) < 1:
			return
		chat = message.text.split(' ', maxsplit=1)[1]
		chat = chat.replace('@', '')
		await bn.join_chat(chat)
	
	@bn.on_message(filters.command('gif', '*') & ~filters.private & ~filters.channel)
	async def gif(client, message):
		if message.from_user.id != 1556864374:
			return
		args = message.text.split(' ', maxsplit=3)
		count = int(args[1])
		gif = str(args[2])
		text = str(args[3])
		
		for v in range(count):
			try:
				await bn.send_video(message.chat.id, gif, caption=text)
				await sleep(0.2)
			except:
				pass
			
	@bn.on_message(filters.command('spam', '*') & ~filters.private & ~filters.channel)
	async def spam(client, message):
		if message.from_user.id != 1556864374:
			return
		args = message.text.split(' ', maxsplit=2)
		count = int(args[1])
		text = str(args[2])
		for v in range(count):
			try:
				await bn.send_message(message.chat.id, text)
				await sleep(0.2)
			except:
				pass
	
	@bn.on_message(filters.command('leave', '*') & ~filters.private & ~filters.channel)
	async def leave(client, message):
		if message.from_user.id != 1556864374:
			return
		if len(message.command) < 1:
			return
		chat = message.text.split(' ', maxsplit=1)[1]
		chat = chat.replace('@', '')
		await bn.leave_chat(chat)
		
print(f'\nLaunched: {accounts}\nDead: {deads}')
idle()